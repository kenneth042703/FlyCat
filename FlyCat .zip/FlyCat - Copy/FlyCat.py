import os
import time
import turtle
import pygame

os.system("cls")
pygame.init()
pygame.mixer.init()
bgmusic = pygame.mixer.Sound("peritune-spook4.mp3")
cat_sound = pygame.mixer.Sound("mixkit-angry-cartoon-kitty-meow-94.wav")
WIDTH, HEIGHT = 250, 150
wid = 10
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("FLY CAT")
screen_color = pygame.Surface((WIDTH, HEIGHT))
screen_color.fill('white')
clock = pygame.time.Clock()
textfont = pygame.font.Font('Pixeltype.ttf', 100)
text = textfont.render("Start", False, 'black')
text_rect = text.get_rect(center=(135, 75))
textbg = pygame.Surface((200, 100))
textbg_rect = textbg.get_rect(center=(130, 70))
textbg.fill('white')
witch = pygame.image.load('witch_2.png').convert_alpha()
run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()
            exit()

    screen.blit(screen_color, (0, 0))
    screen.blit(textbg, textbg_rect)
    screen.blit(text, text_rect)
    pygame.draw.rect(screen, 'black', (30, 20, 200, 100), 2)
    screen.blit(witch, (0, 0))
    pos = pygame.mouse.get_pos()
    if textbg_rect.collidepoint(pos):
        textbg.fill('grey')
        pygame.draw.rect(screen, 'black',(30, 20, 200, 100), 5)
        if event.type == pygame.MOUSEBUTTONDOWN:
            bgmusic.set_volume(0.1)
            bgmusic.play(-1)
            player1 = 1
            player2 = 1
            b = 1
            # Screen
            wn = turtle.Screen()
            wn.title("FlyCat by @Kenneth C. Ritualo")
            wn.bgpic('bg.png')
            wn.setup(width=1300, height=700)
            wn.tracer(5)
            wn.addshape('fire2.gif')
            wn.addshape('fire.gif')
            wn.addshape('cat.gif')
            wn.addshape('cat2.gif')
            wn.addshape('mcat.gif')
            wn.addshape('mcat2.gif')
            wn.addshape('ball.gif')
            # Character1
            character = turtle.Turtle()
            character.speed(0)
            character.shape('cat.gif')
            character.penup()
            character.goto(0, 0)
            # Character2
            character2 = turtle.Turtle()
            character2.speed(0)
            character2.shape("cat2.gif")
            character2.penup()
            character2.goto(0, 0)
            # Obstacle
            obstacle = turtle.Turtle()
            obstacle.speed(0)
            obstacle.shape('fire.gif')
            obstacle.shapesize(stretch_len=3, stretch_wid=3)
            obstacle.penup()
            obstacle.goto(300, 300)
            obstacle.dx = 7
            obstacle.dy = -3
            # Obstacle2
            obstacle2 = turtle.Turtle()
            obstacle2.speed(0)
            obstacle2.shape('fire.gif')
            obstacle2.shapesize(stretch_len=3, stretch_wid=3)
            obstacle2.penup()
            obstacle2.goto(-300, -300)
            obstacle2.dx = -3
            obstacle2.dy = 5
            # Pen_TITLE
            pen = turtle.Turtle()
            pen.speed(0)
            pen.color("Black")
            pen.penup()
            pen.hideturtle()
            pen.goto(0, 260)
            # Character1_FUNCTIONS
            run = True
            def up():
                y = character.ycor()
                y += 80
                character.sety(y)
            def left():
                x = character.xcor()
                x += -80
                character.shape('mcat.gif')
                character.setx(x)
            def right():
                x = character.xcor()
                x += 80
                character.shape('cat.gif')
                character.setx(x)
            def down():
                y = character.ycor()
                y += -80
                character.sety(y)
            # Character2_FUNCTIONS
            def up2():
                y = character2.ycor()
                y += 80
                character2.sety(y)
            def left2():
                x = character2.xcor()
                x += -80
                character2.shape('mcat2.gif')
                character2.setx(x)
            def right2():
                x = character2.xcor()
                x += 80
                character2.shape('cat2.gif')
                character2.setx(x)
            def down2():
                y = character2.ycor()
                y += -80
                character2.sety(y)
            # CONTROLS
            wn.listen()
            wn.onkeypress(down2, "Down")
            wn.onkeypress(left2, "Left")
            wn.onkeypress(up2, "Up")
            wn.onkeypress(right2, "Right")
            wn.onkeypress(down, "s")
            wn.onkeypress(left, "a")
            wn.onkeypress(up, "w")
            wn.onkeypress(right, "d")
            # DISPLAY_FUNCTIONS
            while run or b <= 10000000:
                wn.update()
                # Obstacles_MOVEMENTS
                obstacle.setx(obstacle.xcor() + obstacle.dx)
                obstacle.sety(obstacle.ycor() - obstacle.dy)
                obstacle2.setx(obstacle2.xcor() + obstacle2.dx)
                obstacle2.sety(obstacle2.ycor() + obstacle2.dy)
                character.sety(character.ycor() + 1)
                character2.sety(character2.ycor() + 1)
                b += 1
                pen.clear()
                pen.write("Player1: {} || Player2: {}".format(player1, player2), align="center",
                          font=("Courier", 24, "bold"))
                if character.ycor() > 290:
                    character.goto(character.xcor(), -280)
                elif character.ycor() < -290:
                    character.goto(character.xcor(), 280)
                elif character.xcor() > 510:
                    character.goto(-510, character.ycor())
                elif character.xcor() < -510:
                    character.goto(510, character.ycor())
                if character2.ycor() > 290:
                    character2.goto(character2.xcor(), -280)
                elif character2.ycor() < -290:
                    character2.goto(character2.xcor(), 280)
                elif character2.xcor() > 510:
                    character2.goto(-510, character2.ycor())
                elif character2.xcor() < -510:
                    character2.goto(510, character2.ycor())
                # LOGIC_MOVEMENT for Obstacle1
                if obstacle.ycor() > 290:
                    obstacle.sety(290)
                    obstacle.dy *= -1
                if obstacle.ycor() < -290:
                    obstacle.sety(-290)
                    obstacle.dy *= -1
                if obstacle.xcor() > 490:
                    obstacle.setx(490)
                    obstacle.dx *= -1
                if obstacle.xcor() < -490:
                    obstacle.setx(-490)
                    obstacle.dx *= -1
                if obstacle.xcor() > 0:
                    obstacle.shape('fire.gif')
                if obstacle.xcor() < 0:
                    obstacle.shape('fire2.gif')
                # LOGIC_MOVEMENT for Obstacle2
                if obstacle2.ycor() > 290:
                    obstacle2.sety(290)
                    obstacle2.dy *= -1
                if obstacle2.ycor() < -290:
                    obstacle2.sety(-290)
                    obstacle2.dy *= -1
                if obstacle2.xcor() > 490:
                    obstacle2.setx(490)
                    obstacle2.dx *= -1
                if obstacle2.xcor() < -490:
                    obstacle2.setx(-490)
                    obstacle2.dx *= -1
                if obstacle2.xcor() > 0:
                    obstacle2.shape('fire.gif')
                if obstacle2.xcor() < 0:
                    obstacle2.shape('fire2.gif')
                # LOGIC1.1
                if (character.xcor() + 100 > obstacle.xcor() > character.xcor() - 100) and (
                        character.ycor() + 100 > obstacle.ycor() > character.ycor() - 200):
                    character.goto(0, 0)
                    cat_sound.play()
                    obstacle.dx *= -1
                    b += 100000000
                    pen.clear()
                    pen.write("Player1: 0 || Player2: 0", align="center", font=("Courier", 24, "bold"))
                    player1 = 0
                # LOGIC1.2
                if (character2.xcor() + 100 > obstacle.xcor() > character2.xcor() - 100) and (
                        character2.ycor() + 100 > obstacle.ycor() > character2.ycor() - 200):
                    character2.goto(0, 0)
                    cat_sound.play()
                    obstacle.dx *= -1
                    b += 100000000
                    pen.clear()
                    pen = turtle.Turtle()
                    pen.speed(0)
                    pen.color("Black")
                    pen.penup()
                    pen.hideturtle()
                    pen.goto(0, 260)
                    pen.write("Player1: 0 || Player2: 0", align="center", font=("Courier", 24, "bold"))
                    player2 = 0
                # LOGIC2.1
                if (character.xcor() + 100 > obstacle2.xcor() > character.xcor() - 100) and (
                        character.ycor() + 100 > obstacle2.ycor() > character.ycor() - 200):
                    character.goto(0, 0)
                    cat_sound.play()
                    obstacle2.dx *= -1
                    b += 100000000
                    pen.clear()
                    pen = turtle.Turtle()
                    pen.speed(0)
                    pen.color("Black")
                    pen.penup()
                    pen.hideturtle()
                    pen.goto(0, 260)
                    pen.write("Player1: 0 || Player2: 0", align="center", font=("Courier", 24, "normal"))
                    player1 = 0
                # LOGIC2.2
                if (character2.xcor() + 100 > obstacle2.xcor() > character2.xcor() - 100) and (
                        character2.ycor() + 100 > obstacle2.ycor() > character2.ycor() - 200):
                    character2.goto(0, 0)
                    cat_sound.play()
                    obstacle2.dx *= -1
                    b += 100000000
                    pen.clear()
                    pen = turtle.Turtle()
                    pen.speed(0)
                    pen.color("Black")
                    pen.penup()
                    pen.hideturtle()
                    pen.goto(0, 260)
                    pen.write("Player1: 0 || Player2: 0", align="center", font=("Courier", 24, "normal"))
                    player2 = 0
                # ADD_POINTS
                if character.ycor() + + 20 or character.xcor() + + 20:
                    player1 += 5
                    player2 += 5
                # GAME OVER_LOGIC
                if player1 >= 10000:
                    b += 1000000000
                    wn.clearscreen()
                    wn.bgcolor("black")
                    pen2 = turtle.Turtle()
                    pen2.speed(0)
                    pen2.color("white")
                    pen2.penup()
                    pen2.hideturtle()
                    pen2.goto(0, 0)
                    pen2.write("PLAYER 1 WINS!!!", align="center", font=("Courier", 24, "normal"))
                    time.sleep(3)
                    run = False
                elif player2 >= 10000:
                    b += 1000000000
                    wn.clearscreen()
                    wn.bgcolor("black")
                    pen2 = turtle.Turtle()
                    pen2.speed(0)
                    pen2.color("white")
                    pen2.penup()
                    pen2.hideturtle()
                    pen2.goto(0, 0)
                    pen2.write("PLAYER 2 WINS!!!", align="center", font=("Courier", 24, "normal"))
                    time.sleep(3)
                    run = False
                elif player2 >= 7600 and player1 >= 7600:
                    b += 1000000000
                    wn.clearscreen()
                    wn.bgcolor("black")
                    pen2 = turtle.Turtle()
                    pen2.speed(0)
                    pen2.color("white")
                    pen2.penup()
                    pen2.hideturtle()
                    pen2.goto(0, 0)
                    pen2.write("BOTH OF YOU WINS!!!", align="center", font=("Courier", 24, "normal"))
                    time.sleep(3)
                    run = False
    else:
        textbg.fill('white')
    pygame.display.update()
